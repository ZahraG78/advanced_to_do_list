# file_handler.py

import json
from task import Task


def save_tasks(tasks, filename="tasks.json"):
    data = []

    current = tasks.head
    while current:
        task = current.task
        data.append({
            "name": task._name,
            "due_date": task._due_date,
            "priority": task._priority,
            "completed": task._completed
        })
        current = current.next

    with open(filename, "w") as f:
        json.dump(data, f, indent=4)


def load_tasks(tasks, filename="tasks.json"):
    try:
        with open(filename, "r") as f:
            data = json.load(f)

            for item in data:
                task = Task(
                    item["name"],
                    item["due_date"],
                    item["priority"]
                )
                task._completed = item["completed"]
                tasks.add_task(task)

    except FileNotFoundError:
        pass



    