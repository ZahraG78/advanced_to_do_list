#main 

from task import PersonalTask, TeamTask
from data_structures import LinkedList, Stack, CircularQueue
from graph import Graph
from file_handler import save_tasks
from utils import merge_sort

tasks = LinkedList()
undo_stack = Stack()
reminders = CircularQueue()
dependencies = Graph()

completed_tasks = []

def normalise(text):
    return text.strip().lower() 

# -------------------------------
# CHECK IF TASK CAN BE COMPLETED
# -------------------------------
def can_complete(task_name):
    for dep in dependencies.graph:
        if task_name in dependencies.graph[dep] and dep not in completed_tasks:
            return False
    return True


# -------------------------------
# MAIN MENU
# -------------------------------
def menu():
    while True:
        print("\n===== TASK MANAGEMENT SYSTEM =====")
        print("1. Add Personal Task")
        print("2. Add Team Task")
        print("3. Add Dependency")
        print("4. View Tasks")
        print("5. View Smart Schedule")
        print("6. Critical Path")
        print("7. Mark Task Complete")
        print("8. Run Simulation")
        print("9. Undo")
        print("10. Exit")

        choice = input("Choice: ").strip()

        # -------------------------------
        # ADD PERSONAL TASK
        # -------------------------------
        if choice == "1":
            name = normalise(input("Task Name: "))

            if name in dependencies.get_all_tasks():
                print("Task already exists!")
                continue

            task = PersonalTask(name, "2026-04-10", "High")
            tasks.add_task(task)
            dependencies.add_task(name)
            reminders.enqueue(task)
            undo_stack.push(("add", task))
            print("Task added.")

        # -------------------------------
        # ADD TEAM TASK
        # -------------------------------
        elif choice == "2":
            name = normalise(input("Task Name: ")) 

            if name in dependencies.get_all_tasks():
                print("Task already exists!")
                continue

            members = [m.strip() for m in input("Team Members (comma): ").split(",")]

            task = TeamTask(name, "2026-04-10", "High", members)
            tasks.add_task(task)
            dependencies.add_task(name)
            reminders.enqueue(task)
            undo_stack.push(("add", task))
            print("Team task added.")

        # -------------------------------
        # ADD DEPENDENCY
        # -------------------------------
        elif choice == "3":
            t1 = normalise(input("Task that must be done FIRST: "))
            t2 = normalise(input("Task that depends on it: "))

            if t1 == t2:
                print("A task cannot depend on itself.")
                continue

            if t1 not in dependencies.get_all_tasks() or t2 not in dependencies.get_all_tasks():
                print("Error: One or both tasks do not exist.")
                continue

            dependencies.add_dependency(t1, t2)

            if dependencies.detect_cycle():
                print("Cycle detected! Dependency NOT added.")
                dependencies.graph[t1].remove(t2)
            else:
                print(f"Dependency added: {t1} → {t2}")

        # -------------------------------
        # VIEW TASKS
        # -------------------------------
        elif choice == "4":
            print("\nTASK LIST:")
            tasks.display()

        # -------------------------------
        # SMART SCHEDULE (NO DUPLICATES)
        # -------------------------------
        elif choice == "5":
            order = dependencies.topological_sort()
            # Get actual task objects
            task_objects = []
            for name in order:
                task_obj = tasks.search_task(name)
                if task_obj:
                    task_objects.append(task_obj)

            # Sort by priority
            sorted_tasks = merge_sort(task_objects)

            print("\nSMART TASK SCHEDULE (PRIORITY-BASED)")
            print("------------------------------------")

            for i, task in enumerate(sorted_tasks, 1):
                name = task._name

                if can_complete(name):
                    status = "READY"
                else:
                    status = "BLOCKED"
                    blockers = [
                        dep for dep in dependencies.graph
                        if name in dependencies.graph[dep] and dep not in completed_tasks
                    ]  
                    status = f"BLOCKED (waiting for: {', '.join(blockers)})"

                print(f"{i}. {name} ({task._priority}) [{status}]")  


        # -------------------------------
        # CRITICAL PATH
        # -------------------------------
        elif choice == "6":
            cp = dependencies.critical_path()

            print("\n==============================")
            print("CRITICAL PATH ANALYSIS")
            print("==============================")

            if not cp:
                print("No dependencies found.")
            else:
                print("Longest dependency chain:")
                print(" → ".join(cp))
                print(f"\nProject Duration (steps): {len(cp)}")
                print(f"Bottleneck Task: {cp[-1]}")

        # -------------------------------
        # MARK TASK COMPLETE (FIXED)
        # -------------------------------
        elif choice == "7":
            task_name = normalise(input("Enter task to mark complete: "))

            task_obj = tasks.search_task(task_name)

            if not task_obj:
                print("Task not found!")
            elif task_name in completed_tasks:
                print(f"Task '{task_name}' is already completed.")
            elif can_complete(task_name):
                completed_tasks.append(task_name)
                print(f"Task '{task_name}' successfully marked as complete.")
            else:
                blockers = [
                    dep for dep in dependencies.graph
                    if task_name in dependencies.graph[dep] and dep not in completed_tasks
                ]

                print(f"Task '{task_name}' is BLOCKED. Waiting for: {', '.join(blockers)}")

        # -------------------------------
        # SIMULATION (FULLY FIXED) 
        # -------------------------------
        elif choice == "8":
            order = dependencies.topological_sort()
            completed = []

            print("\n--- SIMULATION START ---\n")

            step = 1

            for task in order:
                print(f"Step {step}:")

                if task in completed_tasks:
                    print(f"✔ {task} has been completed\n")
                    completed.append(task)

                else:
                    blocked = False

                    for parent, children in dependencies.graph.items():
                        if task in children and parent not in completed:
                            blocked = True
                            break

                    if not blocked:
                        completed.append(task)
                        print(f"✔ {task} has been completed\n")
                    else:
                        print(f"✖ {task} is currently blocked\n")

                step += 1

            print("Simulation complete.\n")

        # -------------------------------
        # UNDO
        # -------------------------------
        elif choice == "9":
            action = undo_stack.pop()

            if not action:
                print("Nothing to undo.")
                continue

            if action[0] == "add":
                task_name = action[1]._name

                tasks.delete_task(task_name)

                if task_name in dependencies.graph:
                    del dependencies.graph[task_name]

                for deps in dependencies.graph.values():
                    if task_name in deps:
                        deps.remove(task_name)

                if task_name in completed_tasks:
                    completed_tasks.remove(task_name)

                print(f"Undid adding {task_name}")

        # -------------------------------
        # EXIT
        # -------------------------------
        elif choice == "10":
            save_tasks(tasks)
            print("Tasks saved. Exiting...")
            break

        else:
            print("Invalid choice.")
            print("Please choose a valid option.")
            


# RUN PROGRAM
menu()



