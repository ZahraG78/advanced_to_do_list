# data_structures.py

class Node:
    def __init__(self, task):
        self.task = task
        self.next = None

class LinkedList:
    def __init__(self):
        self.head = None

    def add_task(self, task):
        new_node = Node(task)
        if not self.head:
            self.head = new_node
            return
        current = self.head
        while current.next:
            current = current.next
        current.next = new_node

    def insert_in_order(self, task):
        new_node = Node(task)
        if not self.head or task._due_date < self.head.task._due_date:
            new_node.next = self.head
            self.head = new_node
            return
        current = self.head
        while current.next and current.next.task._due_date <= task._due_date:
            current = current.next
        new_node.next = current.next
        current.next = new_node

    def display(self):
        current = self.head
        while current:
            print(current.task.display())
            current = current.next

    def search_task(self, name):
        current = self.head
        while current:
            if current.task._name == name:
                return current.task
            current = current.next
        return None

    def delete_task(self, name):
        current = self.head
        prev = None
        while current:
            if current.task._name == name:
                if prev:
                    prev.next = current.next
                else:
                    self.head = current.next
                return True
            prev = current
            current = current.next
        return False

class Stack:
    def __init__(self):
        self.items = []

    def push(self, item):
        self.items.append(item)

    def pop(self):
        if self.items:
            return self.items.pop()
        return None

class CircularQueue:
    def __init__(self, size=10):
        self.size = size
        self.queue = [None]*size
        self.front = self.rear = -1

    def enqueue(self, item):
        if (self.rear + 1) % self.size == self.front:
            print("Queue Full!")
            return
        if self.front == -1:
            self.front = 0
        self.rear = (self.rear + 1) % self.size
        self.queue[self.rear] = item

    def dequeue(self):
        if self.front == -1:
            return None
        item = self.queue[self.front]
        if self.front == self.rear:
            self.front = self.rear = -1
        else:
            self.front = (self.front + 1) % self.size
        return item

    def display(self):
        if self.front == -1:
            print("Queue is empty")
            return
        i = self.front
        while True:
            print(self.queue[i].display() if hasattr(self.queue[i], "display") else self.queue[i])
            if i == self.rear:
                break
            i = (i + 1) % self.size

            