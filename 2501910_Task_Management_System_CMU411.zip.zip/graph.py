# graph.py

class Graph:
    def __init__(self):
        self.graph = {}

    def add_task(self, task):
        if task not in self.graph:
            self.graph[task] = []

    def add_dependency(self, task1, task2):
        self.add_task(task1)
        self.add_task(task2)

        if task2 not in self.graph[task1]:
            self.graph[task1].append(task2)

    def detect_cycle(self):
        visited = set()
        rec_stack = set()

        def dfs(node):
            visited.add(node)
            rec_stack.add(node)

            for neighbour in self.graph.get(node, []):
                if neighbour not in visited:
                    if dfs(neighbour):
                        return True
                elif neighbour in rec_stack:
                    return True

            rec_stack.remove(node)
            return False

        for node in self.graph:
            if node not in visited:
                if dfs(node):
                    return True
        return False

    def topological_sort(self):
        visited = set()
        stack = []

        def dfs(node):
            if node in visited:
                return
            visited.add(node)

            for neighbour in self.graph.get(node, []):
                dfs(neighbour)

            stack.append(node)

        for node in self.graph:
            if node not in visited:
                dfs(node)

        return stack[::-1]

    def critical_path(self):
        if not self.graph:
            return []

        order = self.topological_sort()

        dist = {node: 0 for node in self.graph}
        predecessor = {node: None for node in self.graph}

        for u in order:
            for v in self.graph.get(u, []):
                if dist[v] <= dist[u] + 1:
                    dist[v] = dist[u] + 1
                    predecessor[v] = u

        end_node = max(dist, key=dist.get)

        path = []
        while end_node is not None:
            path.append(end_node)
            end_node = predecessor[end_node]

        return path[::-1]

    def get_all_tasks(self):
        return list(self.graph.keys())
    
    