# task.py

class Task:
    def __init__(self, name, due_date, priority):
        self._name = name
        self._due_date = due_date
        self._priority = priority
        self._completed = False

    def mark_complete(self):
        self._completed = True

    def display(self):
        status = "Completed" if self._completed else "Pending"
        return f"{self._name} | Due: {self._due_date} | Priority: {self._priority} | Status: {status}"

class PersonalTask(Task):
    def __init__(self, name, due_date, priority, reminder=True):
        super().__init__(name, due_date, priority)
        self.reminder = reminder

    def display(self):
        return f"[Personal] {super().display()}"

class TeamTask(Task):
    def __init__(self, name, due_date, priority, members):
        super().__init__(name, due_date, priority)
        self.members = members

    def display(self):
        return f"[Team] {super().display()} | Members: {', '.join(self.members)}"
    
    