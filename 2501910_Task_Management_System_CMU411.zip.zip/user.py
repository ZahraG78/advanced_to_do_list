# user.py

class User:
    def __init__(self, name):
        self.name = name

class IndividualUser(User):
    pass

class TeamUser(User):
    def __init__(self, name, members):
        super().__init__(name)
        self.members = members


